# Help

## Command Line Parameters

Passing `-h` or `--help` to Textadept shows a list of available command line
parameters.

## Online Help

Textadept has a [mailing list](http://groups.google.com/group/textadept) and a
[wiki](http://caladbolg.net/textadeptwiki). You can also join us on IRC via
[freenode.net](http://freenode.net) in `#textadept`.

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
